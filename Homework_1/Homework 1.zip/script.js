const UserName = prompt ('Как тебя зовут?');
alert (`Привет, ${UserName}! Очень рад знакомству :-)`);